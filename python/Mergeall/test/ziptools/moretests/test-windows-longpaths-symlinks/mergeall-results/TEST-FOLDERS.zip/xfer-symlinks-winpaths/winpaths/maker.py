"""
--------------------------------------------------------------------
Make a very-long pathname file here for Windows FWP testing.
Example output on Unix (Windows Fix > Raw):
  Raw path len: 417 
  Fix path len: 417 
  File content: End of the line.
--------------------------------------------------------------------
"""
import os, sys
start = os.getcwd()

levels  = 'longpath'
folders = [char * 50 for char in levels]    # 417 = 400 + 8seps + 9file

for folder in folders:
    if not os.path.exists(folder):
        os.mkdir(folder)
    os.chdir(folder)                                   # cd: path short

file = 'afile.txt'
open(file, 'w').write('End of the line.')

os.chdir(start)
fixpath = realpath = os.sep.join(folders + [file])
if sys.platform.startswith('win'):                     # what FWP does
    fixpath = '\\\\?\\' + os.path.abspath(realpath)
wrote = open(fixpath).read()

print('Raw path len:', len(realpath), 
    '\nFix path len:', len(fixpath),
    '\nFile content:', wrote)
