Long paths and symlinks used to test mergeall and ziptools
propagation results - from Unix to Windows, and back to Unix.